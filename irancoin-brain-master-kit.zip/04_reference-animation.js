/**
 * REFERENCE PATTERN — not a full implementation, just the architecture
 * the master prompt requires. Give this to the coding AI alongside
 * 01_MASTER_PROMPT.md if it needs a concrete example of how the brain
 * rotation and the floating halo must stay in separate object graphs.
 *
 * Assumes `scene`, `camera`, `renderer` already exist.
 */

import * as THREE from "three";

// ---- tunable constants -----------------------------------------------
const ROTATION_PERIOD_SECONDS = 26;      // one full 360° turn every N sec
const PULSE_PERIOD_SECONDS = 2.5;
const WOBBLE_PERIOD_SECONDS = 10;
const WOBBLE_DEG = 2;
const BOB_AMPLITUDE_RANGE = [0.06, 0.14]; // world units, tune to your scale
const BOB_FREQUENCY_RANGE = [0.4, 0.8];   // Hz

const clock = new THREE.Clock();
const ROTATION_SPEED = (2 * Math.PI) / ROTATION_PERIOD_SECONDS; // rad/sec

// ---- 1) BRAIN: its own rotation group, nothing else lives inside ------
const brainGroup = new THREE.Group();
scene.add(brainGroup);

// brainMesh = procedurally displaced icosahedron OR imported GLTF scene
// brainGroup.add(brainMesh);

// example emissive pulse target (swap for your actual material/lights)
// const brainMaterial = brainMesh.material;
// const innerLight = new THREE.PointLight(0x7c3aed, 2, 3);
// brainGroup.add(innerLight);

// ---- 2) FLOATING HALO: sibling group, brain rotation never touches it -
const floatingGroup = new THREE.Group();
scene.add(floatingGroup); // sibling of brainGroup, NOT a child of it

const floatingItems = []; // { object3D, baseY, amplitude, frequency, phase }

/**
 * Call once per candle glyph / stat card, positioned on a loose sphere
 * around the brain (radius should clear the brain's own radius).
 */
function addFloatingItem(object3D, basePosition) {
  object3D.position.copy(basePosition);
  floatingGroup.add(object3D);
  floatingItems.push({
    object3D,
    baseY: basePosition.y,
    amplitude: THREE.MathUtils.randFloat(...BOB_AMPLITUDE_RANGE),
    frequency: THREE.MathUtils.randFloat(...BOB_FREQUENCY_RANGE),
    phase: Math.random() * Math.PI * 2,
  });
}

// Example: distribute 10 items on a sphere around the brain.
// (swap `makeCandleGlyph` / `makeStatCard` for your actual mesh/sprite builders)
//
// const COUNT = 10;
// for (let i = 0; i < COUNT; i++) {
//   const phi = Math.acos(1 - (2 * (i + 0.5)) / COUNT);
//   const theta = Math.PI * (1 + Math.sqrt(5)) * i;
//   const radius = 2.4; // clear of the brain's own radius
//   const pos = new THREE.Vector3(
//     radius * Math.sin(phi) * Math.cos(theta),
//     radius * Math.cos(phi),
//     radius * Math.sin(phi) * Math.sin(theta)
//   );
//   const item = i % 2 === 0 ? makeStatCard(STAT_DATA[i]) : makeCandleGlyph();
//   addFloatingItem(item, pos);
// }

// ---- 3) single animation loop -----------------------------------------
function animate() {
  requestAnimationFrame(animate);

  const dt = clock.getDelta();
  const t = clock.getElapsedTime();

  // brain: constant, infinite, delta-time-based rotation — never eased/stopped
  brainGroup.rotation.y += ROTATION_SPEED * dt;

  // small organic wobble, layered on top, does not affect main spin
  brainGroup.rotation.x =
    Math.sin((t * 2 * Math.PI) / WOBBLE_PERIOD_SECONDS) *
    THREE.MathUtils.degToRad(WOBBLE_DEG);

  // pulse (drive this into emissiveIntensity / inner light intensity)
  const pulse = 0.5 + 0.5 * Math.sin((t * 2 * Math.PI) / PULSE_PERIOD_SECONDS);
  // brainMaterial.emissiveIntensity = THREE.MathUtils.lerp(0.6, 1.4, pulse);
  // innerLight.intensity = THREE.MathUtils.lerp(1.0, 2.5, pulse);

  // floating halo: independent bob + billboard to camera
  for (const item of floatingItems) {
    item.object3D.position.y =
      item.baseY + Math.sin(t * item.frequency + item.phase) * item.amplitude;
    item.object3D.quaternion.copy(camera.quaternion); // billboard
  }

  renderer.render(scene, camera);
}

animate();

// ---- resize handling ----------------------------------------------------
window.addEventListener("resize", () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
});
