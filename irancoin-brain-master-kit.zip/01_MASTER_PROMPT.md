# MASTER PROMPT — IRANCOiN "AI Core" 3D Rotating Brain Hero Visual

> Paste this entire file, as-is, to your coding AI (OpenCode CLI). It is written
> to be self-contained: it does not assume the AI remembers any earlier
> conversation. Do not summarize or shorten it before pasting.

---

## ROLE

You are a senior WebGL / Three.js creative front-end engineer who specializes
in cinematic, physically-based 3D visuals for fintech product sites. You ship
production-quality, well-commented, working code — never a partial or
"close enough" result. You treat every line in **HARD REQUIREMENTS** below as
a mandatory acceptance criterion, not a suggestion. Before you say you are
done, you re-read the **ACCEPTANCE TEST** section and verify each line against
your own output.

## CONTEXT

This is the **"هسته هوش مصنوعی" (AI Core)** section of a Persian-language
crypto-trading landing page called **IRANCOiN**. Brand accent color:
`#7C3AED` (violet), on a dark navy/black background, glassmorphism aesthetic.

The section currently shows a brain shape in the center with candle/token
glyphs (₿, Ξ …) and stat cards (`SIGNAL`, `LATENCY`, `WIN RATE`, `RISK`,
`NEURONS`, `ACTIVE`, `DEPTH`, `FLOPS`) placed around it. The current result is
**not acceptable** — it does not look three-dimensional, does not rotate
continuously, and the floating elements do not behave independently of the
brain. **Rebuild this visual from scratch** following the spec below exactly.
Do not reuse the old implementation's animation logic.

---

## HARD REQUIREMENTS

### 1. The brain — must look sculpted, alive, and genuinely three-dimensional

- Build **real WebGL 3D geometry**, not a flat SVG/PNG/CSS icon pretending to
  be 3D. Two acceptable approaches, pick one:
  - **(a) Procedural (preferred, no asset pipeline needed):** start from an
    `IcosahedronGeometry` (subdivision ≥ 4) or a sphere, then displace
    vertices along their normals using 3D simplex/fractal noise to create
    brain-like gyri/sulci (folds and grooves). Recompute vertex normals after
    displacement so lighting reacts correctly to the folds. Split the mesh
    visually into two hemispheres with a subtle central groove.
  - **(b) Imported model:** if a free CC0/CC-BY low-poly brain `.glb`/`.gltf`
    asset is available in the project, load it via `GLTFLoader` instead.
- Material: `MeshPhysicalMaterial` with `roughness` ≈ 0.35–0.5, subtle
  `clearcoat` (≈ 0.4) for a wet/organic sheen, `emissive` set to a violet tone
  matching `#7C3AED`, and a **fresnel/rim-light shader** (custom
  `onBeforeCompile` or `ShaderMaterial`) so the silhouette edges glow brighter
  than the center — this is what reads as "alive" instead of "flat plastic."
- Add 1–2 small point lights *inside* the mesh that pulse (see below) to
  simulate firing synapses, plus one key light and one soft rim light in the
  scene.
- **Pulse (separate from rotation):** animate `emissiveIntensity` (and the
  inner point lights' intensity) with a sine wave, period ≈ 2.2–2.8s, so the
  brain visibly "breathes"/"thinks." This must be continuous and independent
  of the rotation speed below.

### 2. Rotation — the single most important motion rule

- The brain mesh (or its parent `Group`) rotates **continuously and
  infinitely around its own vertical (Y) axis**. `rotation.y` increases every
  frame, forever. There is no start, no stop, no ease-in/ease-out, no pause
  on hover — constant angular velocity.
- Speed: **one full 360° turn every 22–30 seconds** (default 26s). Compute it
  as `angularSpeed = (2 * Math.PI) / ROTATION_PERIOD_SECONDS` and apply
  `group.rotation.y += angularSpeed * deltaTime` every frame using
  `THREE.Clock` (or `useFrame`'s delta in React Three Fiber). Never use a
  fixed per-frame increment — it must be delta-time based so speed is
  identical on 60Hz and 120Hz screens.
- You may layer a **very small** secondary wobble on top (±2° tilt on X,
  slow sine, period ~9–12s) purely for organic feel — but it must never
  slow, reverse, or visibly interrupt the main Y-axis spin.

### 3. Floating elements — candle glyphs & stat/label boxes

- These are the ₿ / Ξ / candlestick glyphs and the stat cards (`SIGNAL`,
  `LATENCY`, `WIN RATE`, `RISK`, `NEURONS`, `ACTIVE`, `DEPTH`, `FLOPS`, plus
  any live numeric values like `+4.2%`, `4ms`, `67.8%`).
- **They live in a completely separate `Group` from the brain's rotation
  group.** They must never be parented to, or inherit rotation from, the
  brain group. This is the #1 mistake to avoid — verify it explicitly.
- Arrange 8–12 of them around the brain using spherical coordinates so they
  form a loose halo, at a radius clearly outside the brain mesh (no overlap).
- Each element **floats independently**:
  - continuous vertical bob: `y = baseY + Math.sin(elapsedTime * frequency + phase) * amplitude`
  - `amplitude` random per item in **6–14px-equivalent world units**
  - `frequency` random per item in **0.4–0.8 Hz**
  - `phase` random per item in `[0, 2π)`
  - so no two elements ever bob in sync.
- Each element **billboards to the camera** every frame (`quaternion.copy(camera.quaternion)`, or use `<Billboard>` in drei) so numbers and Persian/Latin text stay flat and readable — never rotate with the scene.
- Render stat cards as glassmorphism panels: translucent background, blurred
  backdrop, thin border, small glow matching the accent color, rendered
  either as CSS-positioned HTML overlays (via `CSS2DRenderer`/`Html` from
  drei, projected from their 3D position) or as 3D planes with canvas
  textures — either is fine as long as billboarding + independent float are
  preserved.

### 4. Camera, lighting, scene

- Perspective camera, FOV 35–45°, positioned so the brain fills roughly
  55–65% of the frame's vertical height with room for the floating halo.
- Optional slow auto-orbit of the **camera** (not the brain) is allowed but
  must not be confused with requirement 2; if used, make it slow and subtle
  (full camera orbit ≥ 90s) and clearly documented as separate from the
  brain's own spin.
- Dark background matching the section's existing navy/black, with soft
  volumetric-looking ambient glow in the accent violet behind the brain.

### 5. Tech & code structure

- Detect and match the project's actual stack. This project is a **static
  multi-page HTML/CSS/vanilla-JS site** (`index.html`, `pricing.html`,
  `dashboard.html`) — assume **vanilla Three.js via a bundler or CDN import**
  unless you find an existing React setup in the repo; if React + React
  Three Fiber is already used elsewhere, use `@react-three/fiber` + `drei`
  instead and follow the same rules using `useFrame`.
- Structure the code into clear, separated pieces:
  - `createBrain()` — geometry, material, mesh, returns the brain `Group`.
  - `createFloatingHalo()` — builds the candle/stat objects, returns their
    `Group` + an array of `{ object3D, baseY, amplitude, frequency, phase }`.
  - a single `animate(time)` loop that (1) advances brain rotation, (2)
    advances the pulse, (3) updates every floating item's bob + billboard,
    (4) renders.
- Use post-processing (`UnrealBloomPass` or the `postprocessing` npm
  package) for the glow: `strength` 0.6–0.9, `radius` 0.4, `threshold` 0.15.

### 6. Performance & responsiveness

- Cap `renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))`.
- Resize handling: update camera aspect + renderer size on window resize
  (debounced), and on mobile reduce floating-item count to 4–6 and disable
  or lighten bloom.
- Respect `prefers-reduced-motion`: if set, keep the brain's pulse but slow
  rotation to a near-static crawl and remove the wobble/bob amplitude by
  ~70% rather than freezing everything completely.
- Target 60fps on a mid-range laptop GPU; keep the brain mesh under ~15k
  triangles.

---

## ABSOLUTE DO-NOT LIST

- ❌ Do NOT parent the floating candles/stat boxes to the brain's rotation
  `Group`, and do NOT let them share its rotation in any way.
- ❌ Do NOT fake 3D with a flat image, CSS 3D transform on a 2D sprite, or a
  static pre-rendered GIF/PNG.
- ❌ Do NOT ease, pause, reverse, or stop the main Y-axis rotation at any
  point (including on hover/click) unless the user explicitly asks for that
  later.
- ❌ Do NOT let floating elements spin/tumble — they only bob vertically and
  billboard to the camera; their rotation must always face the viewer.
- ❌ Do NOT use a fixed per-frame rotation increment (e.g. `+= 0.01` inside a
  loop with no delta time) — this breaks speed consistency across refresh
  rates.
- ❌ Do NOT skip the fresnel/rim-light and emissive pulse — without them the
  brain reads as flat plastic instead of "alive."
- ❌ Do NOT ignore mobile performance or `prefers-reduced-motion`.

---

## DELIVERABLE

1. Working, integrated code inside the actual project (not a separate demo
   page), wired into the existing "AI Core" section markup/container.
2. Keep the existing Persian copy, stat labels, and numeric values — only
   replace the visual/animation implementation.
3. A short comment block at the top of the main animation file listing the
   configurable constants (`ROTATION_PERIOD_SECONDS`, bob amplitude/frequency
   ranges, bloom params) so they can be tuned later without reading the whole
   file.

---

## ACCEPTANCE TEST (run this yourself before declaring the task done)

- [ ] I loaded the page and watched it for a full 60 seconds: the brain
      rotated continuously the entire time, at a constant, unchanging speed,
      never pausing or reversing.
- [ ] The brain has visible light/shadow across its curved surface — it
      looks like a solid sculpted object, not a flat outline.
- [ ] The brain's silhouette glows brighter at the edges (rim light) and its
      overall glow pulses continuously (breathing effect).
- [ ] I confirmed in the code that the floating candles/stat boxes are in a
      `Group` that is a **sibling**, not a **child**, of the brain's rotation
      group.
- [ ] I watched the floating elements for 15 seconds: each one bobs up and
      down independently, out of sync with the others and with the brain's
      rotation.
- [ ] All text/numbers inside the floating cards stayed upright and
      readable the entire time (billboard confirmed).
- [ ] Resizing the browser window keeps everything correctly framed.
- [ ] On a throttled/mobile viewport the scene still runs smoothly with
      fewer floating items and lighter bloom.

If any box above is not true, fix it before responding that the task is
complete.
