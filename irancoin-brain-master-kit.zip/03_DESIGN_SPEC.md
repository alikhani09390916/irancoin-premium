# Design Spec — "AI Core" Brain Scene (visual tokens)

> No Figma file link was shared in this conversation, so this document
> serves as a text-based design handoff (same purpose as a Figma dev-mode
> panel). If you share an actual Figma file URL with me later, I can pull
> exact tokens from it directly with the Figma tool and update this file.

## Color tokens (matches the site's existing `#7C3AED` theme)

| Token | Value | Use |
|---|---|---|
| `--brain-accent` | `#7C3AED` | brain emissive / rim glow / bloom tint |
| `--brain-accent-soft` | `rgba(124, 58, 237, 0.55)` | ambient glow behind brain |
| `--bg-scene` | `#0B0B14` | scene / section background |
| `--card-bg` | `rgba(255, 255, 255, 0.06)` | stat/label card fill |
| `--card-border` | `rgba(255, 255, 255, 0.12)` | stat/label card border, 1px |
| `--card-blur` | `16px` | `backdrop-filter: blur(...)` |
| `--text-primary` | `#F5F5F7` | card numeric value |
| `--text-secondary` | `rgba(245, 245, 247, 0.6)` | card label text |
| `--candle-up` | `#22D3EE` | bullish candle glyph accent (optional) |
| `--candle-down` | `#F87171` | bearish candle glyph accent (optional) |

## Sizing

- Brain diameter: **40–46%** of container height on desktop, **≈60%** on
  mobile (with fewer floating items, see below).
- Stat/label card: width `120–160px`, `border-radius: 16px`,
  `padding: 12–16px`.
- Card value text: `20–24px`, weight 700.
- Card label text: `11–12px`, uppercase, `letter-spacing: 0.06em`.
- Floating halo radius: outside the brain mesh with a visible gap — roughly
  1.4–1.8× the brain's own radius.

## Motion tokens

| Token | Value |
|---|---|
| Brain rotation period | 22–30s per full 360° turn (default **26s**) |
| Brain pulse period | 2.2–2.8s |
| Secondary wobble (tilt) | ±2°, period 9–12s |
| Float bob amplitude | 6–14px-equivalent, unique per item |
| Float bob frequency | 0.4–0.8 Hz, unique per item |
| Bloom strength / radius / threshold | 0.6–0.9 / 0.4 / 0.15 |
| Camera FOV | 35–45° |

## Element count by breakpoint

| Breakpoint | Floating items |
|---|---|
| Desktop (≥1024px) | 8–12 |
| Tablet (768–1023px) | 6–8 |
| Mobile (<768px) | 4–6 |

## Content mapping (reuse existing copy — do not invent new labels)

Candle/token glyphs: `₿`, `Ξ` (and any others already in the section).

Stat cards (label → sample value already on the page):
- `SIGNAL` → `+4.2%`
- `LATENCY` → `4ms`
- `WIN RATE` → `67.8%`
- `RISK` → `متوسط`
- `NEURONS` → `80`
- `ACTIVE` → status dot
- `DEPTH` → `5L`
- `FLOPS` → `2.4T`
