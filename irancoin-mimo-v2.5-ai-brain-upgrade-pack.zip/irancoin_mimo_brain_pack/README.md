# IRANCOIN MIMO v2.5 Brain Upgrade Pack

This package is designed to be dropped into the repository and supplied to MIMO v2.5 Free through OpenCode CLI.

## Recommended use
1. Copy the `docs/`, `reference/`, and `starter/` folders into the project root (or point MIMO to this package).
2. Paste `docs/MASTER_PROMPT_MIMO_V2_5.md` as the main task prompt.
3. Tell MIMO to execute the phases sequentially and verify after each phase.
4. Treat `docs/TODO.md` as a mandatory execution checklist.
5. Treat `docs/ACCEPTANCE_CRITERIA.md` as the final visual gate.
6. Treat `docs/FIGMA_HANDOFF.md` as the composition contract when building a Figma reference.
7. Use `reference/VISUAL_REFERENCE_PROMPT.txt` as the image-generation / visual-reference prompt if an image model or reference generator is available.

## Important
The pack is intentionally NOT a fake prebuilt claim of a finished brain asset. The goal is to give MIMO a strict implementation contract so it builds the 3D scene inside the real site rather than repeatedly producing a flat approximation.
