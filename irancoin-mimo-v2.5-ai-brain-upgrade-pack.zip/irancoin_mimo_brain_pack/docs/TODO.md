# IRANCOIN AI Brain — Mandatory TODO

## Audit
- [ ] Inspect current AI Core DOM and JS/CSS.
- [ ] Locate all old brain rendering code.
- [ ] Locate existing floating stat/ticker elements.
- [ ] Record current dependencies and asset paths.

## 3D Brain
- [ ] Build or integrate a genuinely volumetric brain.
- [ ] Verify both hemispheres and central fissure are readable.
- [ ] Add cortical folds / neural structure.
- [ ] Use layered materials and controlled bloom.

## Motion
- [ ] Brain own-axis Y rotation enabled.
- [ ] Rotation is delta-time based.
- [ ] Rotation speed configurable.
- [ ] Floaters NOT parented to brain rotation group.
- [ ] Each floater has independent phase/amplitude/speed.
- [ ] Neural pulse animation enabled.
- [ ] Subtle data particles enabled.

## Trading Visuals
- [ ] 3D candles with body + wick.
- [ ] BTC / USDT visual elements.
- [ ] Glass stat cards.
- [ ] 3D depth distribution.
- [ ] Preserve readable orientation.

## UX / Responsive
- [ ] Pointer/touch parallax.
- [ ] Responsive stage sizing.
- [ ] Mobile reduction strategy.
- [ ] prefers-reduced-motion.
- [ ] No overlap with hero text.

## Engineering
- [ ] One renderer only.
- [ ] No duplicate import map.
- [ ] ResizeObserver installed.
- [ ] IntersectionObserver used when beneficial.
- [ ] No per-frame DOM layout reads.
- [ ] Cleanup path implemented.
- [ ] No unrelated site regressions.

## QA
- [ ] Local preview launched.
- [ ] Console checked.
- [ ] Network errors checked.
- [ ] Desktop checked.
- [ ] Mobile checked.
- [ ] Brain rotation visually verified.
- [ ] Floater independence visually verified.
- [ ] 360-degree depth visually verified.
- [ ] Reduced motion verified.

## Completion Gate
- [ ] All boxes above pass.
- [ ] Screenshots/video evidence captured when tooling permits.
- [ ] Final changed-file list reported.
