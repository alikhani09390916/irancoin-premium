# IRANCOIN AI Core — Visual Acceptance Criteria

A human reviewer should be able to answer YES to every item below without inspecting source code.

1. The central object unmistakably resembles a three-dimensional human brain.
2. The brain has visible front/side/rear depth as it turns.
3. The silhouette has two hemispheres and a central separation.
4. The brain rotates around itself continuously.
5. The rotation is slow, smooth, premium, and never jerky.
6. Candles and cards do NOT rotate with the brain.
7. Floating objects have different phases and do not move in lockstep.
8. Candles visibly occupy different depths.
9. Cards look like translucent glass UI objects rather than flat screenshots.
10. The neural layer subtly pulses and flickers.
11. Glow is restrained enough to preserve structure.
12. The brain remains the visual focal point.
13. Desktop composition feels spacious and cinematic.
14. Mobile composition remains readable without destructive overlap.
15. Pointer parallax is subtle and does not fight automatic rotation.
16. Reduced-motion mode remains usable and accessible.
17. No obvious frame stutter is visible on a normal device.
18. No console errors are produced during normal load/resize/interact flows.
19. Existing IRANCOIN navigation and CTA behavior remain intact.
20. The implementation is a real 3D scene, not a 2D trick.
