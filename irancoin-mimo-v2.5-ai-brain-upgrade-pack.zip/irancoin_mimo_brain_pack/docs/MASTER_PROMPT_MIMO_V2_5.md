# IRANCOIN — MIMO v2.5 FREE / OpenCode CLI MASTER PROMPT

## ROLE
You are a senior creative-coding engineer, 3D web graphics engineer, motion designer, and UI implementation specialist. You are working inside the existing IRANCOIN website repository.

Your task is NOT to make a decorative approximation. Your task is to REBUILD the hero "AI Core / هسته هوش مصنوعی" visual as a genuinely three-dimensional, premium, continuously animated, interactive AI-brain scene that meets every requirement below.

The current public reference site is:
https://alikhani09390916.github.io/irancoin-premium/

The current page already contains the AI Core hero concept with BTC/USDT-style floating information, stats, market labels, and a section titled around the AI brain. Preserve the site's existing product meaning and surrounding layout; replace only the weak/flat AI-core visual implementation.

Reference observations from the current page:
- The hero currently presents the AI core with BTC (₿), Tether (₮), market analysis, execution speed, risk, trading signal, and ticker-like values.
- The page later introduces the AI section as the digital brain that reads and understands the market.
- Existing visual language is premium fintech / dark / futuristic with Persian RTL content.

## PRIMARY VISUAL TARGET
Create a CENTRAL HUMAN-BRAIN-INSPIRED 3D AI CORE that is visibly volumetric, rounded, shaded, luminous, and alive.

The brain must:
1. Clearly read as a human brain silhouette from multiple angles.
2. Have real depth and volume — never a flat SVG, flat PNG, CSS silhouette, or 2D card pretending to be 3D.
3. Rotate around its OWN vertical axis continuously and smoothly.
4. Rotate slowly enough to feel premium, but fast enough that the 3D depth is obvious.
5. Keep its orientation stable around the center while subtle independent neural animation creates life.
6. Have visible neural grooves / cortical folds / branching structures.
7. Use layered materials: translucent shell/glow + emissive neural filaments + subtle inner core.
8. Have cinematic lighting and soft bloom without washing out its silhouette.
9. Produce a convincing "AI intelligence core" rather than a literal biological medical brain.
10. Remain crisp and premium at mobile and desktop widths.

## NON-NEGOTIABLE MOTION RULE
The BRAIN rotates. The surrounding cards, candles, labels, tickers, and glyphs do NOT rotate with the brain.

There are two independent motion systems:

A) CORE ROTATION
- The brain object/group rotates continuously around its own Y axis.
- Use smooth frame-rate-independent motion.
- Target a premium slow orbit feel, approximately 8–14 degrees per second, with a tunable config constant.
- No sudden acceleration.
- No stutter.
- No full-scene rotation.

B) ORBITING FLOATERS
- Candle sticks, stat boxes, BTC/ETH/USDT glyphs, labels, and data chips float independently around the brain.
- They may gently bob, drift, and parallax, but they must NOT be parented to the rotating brain.
- Each floater should have its own phase, amplitude, and speed so the scene does not look mechanically synchronized.
- Preserve readable orientation toward the camera.
- Use subtle depth movement and gentle micro-rotation only where appropriate.

## CAMERA / COMPOSITION
Use a true 3D perspective camera.

Desktop:
- Brain centered in the AI Core visual stage.
- Brain occupies roughly 45–60% of the visual stage height.
- Leave clear breathing room around the brain for floating cards.
- Slight camera perspective, not orthographic flatness.
- Mild depth-of-field-style illusion if performance allows, but never blur the primary brain.

Mobile:
- Keep the brain dominant.
- Reduce floater count before reducing brain size.
- Never let cards overlap the brain's critical silhouette.
- Keep the rotation visible.

## BRAIN GEOMETRY REQUIREMENTS
Do NOT use a low-detail sphere with a few blobs.

Preferred implementation order:
1. Best: a proper brain-shaped GLTF/GLB 3D model that can legally/technically be bundled or referenced.
2. Acceptable: a procedural brain mesh built from multiple lobe volumes / implicit surfaces / carefully deformed geometry.
3. Acceptable fallback: a dense point/curve neural brain constructed from many 3D paths around a volumetric brain form.

If a real 3D asset is unavailable, build a convincing procedural approximation.

The result must visually communicate:
- two hemispheres
- central fissure
- cortical folds
- organic outer contour
- tapered brain stem
- rounded posterior region

Avoid:
- simple ball
- simple capsule
- flat neural network logo
- wireframe-only brain
- 2D displacement over a plane
- a single glowing outline

## MATERIAL DESIGN
Use a premium IRANCOIN fintech palette:
- deep navy / near-black environment
- cyan / electric blue neural energy
- subtle violet accents
- small controlled mint/green market accents
- white/soft-blue typography

The brain should NOT become a rainbow object.

Recommended material stack:
- base brain surface: dark translucent/metallic material with subtle blue-violet emissive contribution
- neural grooves/filaments: emissive cyan/blue with varying brightness
- inner core: soft volumetric glow / point lights / particles
- selective rim light on the silhouette

Bloom must be controlled. Preserve shape definition.

## NEURAL ANIMATION
The neural layer must feel alive.

Implement several subtle layers:
- slow pulse traveling through neural paths
- intermittent micro-flickers on small branches
- tiny particles / data sparks moving along selected pathways
- very subtle breathing/pulse of the core intensity

These animations must not overpower the primary rotation.

## TRADING ELEMENTS
Around the brain, create a curated 3D composition of floating financial objects.

Include a mixture of:
- 3–5 candlestick clusters
- BTC glyph / coin-like element
- USDT / Tether glyph or coin-like element
- market signal card
- latency/execution card
- risk card
- neural/processing metric card
- compact BTC/USDT ticker

Important:
- These are part of the 3D composition, not a flat HTML collage pasted over the brain.
- They should occupy different depth planes.
- Some should be closer, some farther.
- Avoid symmetry that looks artificial.
- Keep the visual weight centered on the brain.

## CANDLE DESIGN
Candles must read as real 3D trading candlesticks.

Each candle should have:
- a 3D body
- a wick
- correct green/red distinction
- slight reflective/emissive material response
- subtle floating movement

Candles should NOT rotate as a single locked chart plane.

Use several small groups with independent placement.

## FLOATING LABEL / STAT CARD DESIGN
Cards must be:
- translucent glass / frosted panel
- thin border
- soft outer glow
- subtle depth shadow
- slightly rounded corners
- readable at a glance

Use real HTML/CSS cards OR 3D planes with carefully managed DOM overlays; choose the implementation that gives the cleanest readability while preserving 3D depth.

The cards must stay visually anchored near their intended 3D positions as the camera/brain moves.

Recommended sample content:
- SIGNAL +4.2%
- LATENCY 4ms
- WIN RATE 67.8%
- RISK کم
- NEURONS 80
- ACTIVE ●
- DEPTH 5L
- FLOPS 2.4T
- BTC/USDT +2.4%
- ETH/USDT -0.8%

These are presentation placeholders only. If the repo already exposes real values, bind to those values instead of hardcoding new fake data.

## 360-DEGREE REQUIREMENT
The visual must visibly work as a 360-degree object.

The user must be able to see depth changes as the brain turns:
- front folds
- side contour
- rear contour
- depth separation between hemispheres
- perspective changes in the neural surface

Do not create an animation where the brain appears to be a flat drawing being rotated.

## INTERACTION
Add subtle pointer interaction:
- mouse/touch movement produces a SMALL camera parallax offset
- hover/focus can increase neural intensity slightly
- no violent camera movement
- no breaking the hero layout

The automatic brain rotation continues while pointer parallax happens.

## PERFORMANCE
Target smooth motion.

Requirements:
- requestAnimationFrame or equivalent render loop
- delta-time based animation
- ResizeObserver for the stage
- pixel ratio capped appropriately for mobile devices
- pause/throttle heavy rendering when the section is far outside the viewport if appropriate
- use IntersectionObserver where useful
- avoid per-frame DOM layout reads
- avoid unnecessary object creation inside the render loop
- clean up renderer, listeners, and observers on teardown
- support prefers-reduced-motion

Reduced-motion mode:
- keep a static 3D brain or extremely slow movement
- disable intense particle motion
- keep content accessible and visible

## IMPLEMENTATION ARCHITECTURE
Prefer Three.js if the repository is static HTML/JS and does not already have a better 3D engine.

Use modules.

Suggested structure:
- ai-brain-scene.js
- ai-brain-scene.css
- optional brain asset under assets/models/
- optional texture assets under assets/textures/

Do not create duplicate import maps.
Do not create multiple renderers for the same stage.
Do not leak animation frames or event listeners.

## EXISTING SITE INTEGRATION
The current site is a Persian RTL landing page with an AI Core hero area.

You must FIRST inspect the repository and identify:
- exact AI Core DOM block
- existing scripts
- existing CSS
- current brain/3D code
- current floating stat/card code
- any existing dependencies

Do not blindly overwrite the rest of the homepage.

Remove or disable the old brain renderer only after the new scene is ready to mount.

Do not break:
- navigation
- pricing
- login/register modal
- CTA buttons
- dashboard links
- existing floating cards outside the AI Core scene
- RTL layout
- responsive behavior

## CRITICAL DEBUGGING RULE
Never declare success because a file exists.

The feature is only complete when you inspect the actual rendered page and verify visually and technically.

You MUST:
1. run the site locally
2. open the page in a browser-capable environment if available
3. inspect console errors
4. inspect runtime errors
5. check the AI Core stage dimensions
6. verify brain rotation visually
7. verify independent floater motion
8. verify responsive behavior
9. verify reduced-motion behavior
10. verify there is only one active renderer for the AI Core

If a test fails, fix it, retest, and only then continue.

## HARD NEGATIVE CONSTRAINTS
Do NOT:
- make the brain a static image
- make the brain a flat SVG
- make the brain a CSS outline
- spin the entire stage
- spin HTML cards together with the brain
- use a single plane texture as the brain
- hide the brain behind excessive cards
- use excessive bloom that destroys the silhouette
- add unnecessary random particles everywhere
- rewrite unrelated sections of the site
- change product wording without reason
- remove RTL
- hardcode new live financial values when existing data exists
- claim "360-degree" if the visual still looks flat

## DEFINITION OF DONE
The result passes only if all statements below are true:

[ ] A viewer immediately sees a 3D human-brain-like AI core.
[ ] The brain has clear volumetric depth and shading.
[ ] The brain rotates continuously around its own axis.
[ ] Rotation is smooth and premium, not fast or mechanical.
[ ] Brain rotation and floater motion are independent.
[ ] Candles float in 3D space and remain visually readable.
[ ] Stat cards float independently around the brain.
[ ] The object reads correctly from multiple angles.
[ ] Neural energy animates subtly.
[ ] The scene keeps its composition on mobile and desktop.
[ ] No console errors occur.
[ ] No duplicate renderer/import-map problem occurs.
[ ] Existing page functionality remains intact.
[ ] prefers-reduced-motion is respected.
[ ] Performance remains acceptable on typical mobile hardware.

## EXECUTION MODE
Work in phases and do not skip verification.

PHASE 0 — AUDIT
- inspect repository
- inspect current AI Core implementation
- identify the weakest existing brain implementation
- write a short audit summary

PHASE 1 — SCENE FOUNDATION
- build/obtain the volumetric brain
- establish camera, lights, renderer
- establish continuous own-axis rotation

PHASE 2 — NEURAL LIFE
- add neural filaments
- add pulsing/flicker animation
- add restrained particle/data motion

PHASE 3 — TRADING ORBITALS
- add independent 3D candles
- add BTC/USDT elements
- add glass stat cards
- keep all orbiters independent from the brain rotation

PHASE 4 — RESPONSIVE + INTERACTION
- mouse/touch parallax
- ResizeObserver
- mobile composition
- reduced-motion support

PHASE 5 — INTEGRATION
- replace old renderer only after new scene is ready
- preserve all existing site sections

PHASE 6 — QA
- local run
- visual verification
- console verification
- responsive verification
- cleanup

After each phase, report:
- changed files
- what was tested
- pass/fail
- remaining issues

Do NOT ask me routine questions. Only stop and ask when an irreversible action, secret/API key, OAuth credential, paid service, destructive deletion, or publishing/deployment decision is required.

## FINAL DELIVERABLE
At the end provide:
1. exact files changed/created
2. concise explanation of the scene architecture
3. QA results
4. any remaining known limitation
5. exact command(s) I should use in OpenCode CLI if another run is needed

The priority order is:
3D DEPTH > BRAIN SHAPE > INDEPENDENT MOTION > SMOOTHNESS > READABILITY > EFFECTS.

Do not sacrifice the first four priorities for decorative effects.
