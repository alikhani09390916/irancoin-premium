# Figma Handoff — IRANCOIN AI Core Hero

## Purpose
Use this file as the visual contract when creating the hero composition in Figma before implementation.

## Frame
- Desktop reference: 1440 × 900
- Tablet reference: 1024 × 900
- Mobile reference: 390 × 844
- Safe area: keep the primary brain away from screen edges.

## Composition
- Brain is the dominant central visual.
- Brain visual width target: ~520–680 px on desktop depending on viewport.
- Hero text remains visually separate from the 3D stage.
- Floaters form an irregular depth-aware ring around the brain.
- No single floater should visually overpower the brain.

## Visual hierarchy
1. Brain silhouette
2. Neural glow / energy
3. Candles and BTC/USDT objects
4. Glass metric cards
5. Micro particles

## Card language
- Rounded corners: 14–20 px
- Thin translucent borders
- Soft glass background
- Compact metric typography
- Large number, small label
- Tiny status indicator where relevant

## Motion notes for prototype
Figma is only the choreography reference. Actual 3D rotation must be implemented in Three.js or an equivalent 3D runtime.

Prototype motion targets:
- Brain: continuous slow rotation
- Floaters: independent gentle bob/orbit
- Neural pulses: intermittent subtle glow
- Pointer parallax: low amplitude

## Do not fake in Figma
Do not present a static 2D brain as the implementation target. The Figma artifact is a composition blueprint only; the production scene must be volumetric.
