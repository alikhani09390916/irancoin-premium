# Suggested Scene Architecture

Scene root
├── BrainRoot (rotates on Y only)
│   ├── BrainSurface
│   ├── NeuralFilaments
│   ├── InnerGlow
│   └── NeuralParticles
├── FloaterRoot (DO NOT parent to BrainRoot)
│   ├── CandleCluster A
│   ├── CandleCluster B
│   ├── BTC Element
│   ├── USDT Element
│   ├── MetricCard SIGNAL
│   ├── MetricCard LATENCY
│   ├── MetricCard RISK
│   └── MetricCard NEURONS
├── CameraRig
└── Lights

Animation loop
1. read delta time
2. rotate BrainRoot
3. update neural pulse
4. update each floater independently using its own phase/speed
5. apply small pointer-parallax camera offset
6. render

Never call BrainRoot.add(floater).
Never rotate the scene/root container as a substitute for rotating the brain.
